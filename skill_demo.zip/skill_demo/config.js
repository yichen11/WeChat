module.exports = {
    version: '0.0.2',
    copyleft: '© 2016 Geekbang Technology Ltd. Some rights reserved.'
}
